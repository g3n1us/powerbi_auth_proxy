<?php
// 7d8cc48463fce39e7b52bfcb05fd44fc
?>
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	  
		<title>Auth Proxy Admin</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<style>
			fieldset[disabled]{
				display: none;
			}
			
			#outer fieldset:last-child [data-direction="down"]{
				display: none;
			}
			
			#outer fieldset:first-child [data-direction="up"]{
				display: none;
			}
		</style>
	</head>	
	<body>
		<div class="container pt-3">
			<nav class="container nav nav-tabs">
				<a class="nav-item nav-link active" href="#edit-reports">Edit Reports</a>
				<a class="nav-item nav-link" href="#edit-admin-users">Edit Users</a>
				<a class="nav-item nav-link" href="#available-updates">Available Updates</a>
			</nav>			
		</div>
		<div id="messages" class="container"></div>
		<div class="tab-content">
			<div class="tab-pane fade in show active" id="edit-reports">
							<div class="container">
				<div class="row">
					<div class="col-md-12 py-5" id="main_content">
						<h2>Auth Proxy Admin
							<br><small class="text-muted">add/remove/edit and rearrange reports</small>
						</h2>
						
						<script type="text/template">{"reports":[{"id":"82ec1032-d3b0-4546-823f-8868ca16f267","name":"Overview","type":"power_bi","slug":"82ec1032d3b04546823f8868ca16f267","handle":"overview","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"2b3de730-be7e-4a14-b2f3-1e6be27be96f","name":"Recency","type":"power_bi","slug":"2b3de730be7e4a14b2f31e6be27be96f","handle":"recency","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"5e932ae1-deba-4a19-9d78-4033af3d12db","name":"Lab Quality Control","type":"power_bi","slug":"5e932ae1deba4a199d784033af3d12db","handle":"lab-quality-control","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"1b7b7867-bdd8-4e31-938d-0c20565e173a","name":"Quality Indicators","type":"power_bi","slug":"1b7b7867bdd84e31938d0c20565e173a","handle":"quality-indicators","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"447ce3d7-b5fa-4b61-8d76-2cf1175ea353","name":"Facility Monitoring","type":"power_bi","slug":"447ce3d7b5fa4b618d762cf1175ea353","handle":"facility-monitoring","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839","name":"EPI Bulletin","type":"power_bi","slug":"8e6f2bbd26814b2cbc0ce3ba9062c839","handle":"epi-bulletin","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"884d4548-1cec-4390-ba99-47ed4319819e","name":"Cluster Detection & Response","type":"power_bi","slug":"884d45481cec4390ba9947ed4319819e","handle":"cluster-detection---response","url":"https:\/\/app.powerbi.com\/reportEmbed"},{"id":"0d0965112ee147b9859f69d7e64cb250","name":"Cluster Detection & Response (Maps)","type":"esri","slug":"0d0965112ee147b9859f69d7e64cb250","handle":"cluster-detection---response--maps-","url":"https:\/\/www.arcgis.com\/apps\/opsdashboard\/index.html?token=ts0ehRoneVGMXW4X8qkg8Or6Mn3h7dCDh7I8OMAnc4ig_Y6PXKQcyxOBODPsw54Kyroy_cyAZjU4Fo5QgiXRAe7beBbXEhxa5VzlY5sP66HRiV3FsbR1N-OJk7r3GOlMyeyNNf7K0GS4IWpMnbIaag..#\/0d0965112ee147b9859f69d7e64cb250"},{"id":null,"type":null,"name":null}],"users":["sbethel@blueraster.com",null],"versions":[],"users_versions":[{"version":"1594865557","timestamp":"2020-07-16T02:12:37.000000Z","data":["sbethel@blueraster.com"]}]}</script>
						
						<div class="text-right py-3">
							<a href="#versions_collapse" class="text-muted" data-toggle="collapse">versions</a>
						</div>
						<div class="collapse" id="versions_collapse">
							<form class="text-right text-muted py-3" id="version_form">
								<div class="input-group">
									<div class="input-group-prepend">
										<label class="input-group-text" for="version_select">Versions</label>
									</div>
									
									<select class="custom-select" name="_version" id="version_select">
										<option value="">LATEST</option>
																	
									</select>
									<div class="input-group-append">
										<button class="btn btn-outline-secondary" type="submit">ok</button>
									</div>
								</div>
																
							</form>
						</div>
						<form method="post">
							<input type="hidden" name="csrf_test_name" value="ce63651d858a4a25153107b6e26ca3b3" />							<div class="sticky-top py-3 d-flex bg-white border-bottom">
								<button type="button" class="btn btn-lg btn-primary"  data-action="add">Add Report</button>
								<button type="submit" class="btn btn-lg btn-success ml-auto">Save</button>
							</div>
							
							<div class="outer">
								
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="82ec1032-d3b0-4546-823f-8868ca16f267id" id="82ec1032-d3b0-4546-823f-8868ca16f267id_label">Report ID</label>
										</div>
										<input type="text" name="reports[82ec1032-d3b0-4546-823f-8868ca16f267][id][]" required class="form-control" id="82ec1032-d3b0-4546-823f-8868ca16f267id" aria-describedby="82ec1032-d3b0-4546-823f-8868ca16f267id_label" value="82ec1032-d3b0-4546-823f-8868ca16f267">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Overviewname" id="Overviewname_label">Report Label</label>
										</div>
										<input type="text" name="reports[82ec1032-d3b0-4546-823f-8868ca16f267][name][]" class="form-control" id="Overviewname" aria-describedby="Overviewname_label" value="Overview">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="82ec1032-d3b0-4546-823f-8868ca16f267type">Report Type</label>
										</div>
										<select id="82ec1032-d3b0-4546-823f-8868ca16f267type" class="custom-select" required name="reports[82ec1032-d3b0-4546-823f-8868ca16f267][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="2b3de730-be7e-4a14-b2f3-1e6be27be96fid" id="2b3de730-be7e-4a14-b2f3-1e6be27be96fid_label">Report ID</label>
										</div>
										<input type="text" name="reports[2b3de730-be7e-4a14-b2f3-1e6be27be96f][id][]" required class="form-control" id="2b3de730-be7e-4a14-b2f3-1e6be27be96fid" aria-describedby="2b3de730-be7e-4a14-b2f3-1e6be27be96fid_label" value="2b3de730-be7e-4a14-b2f3-1e6be27be96f">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Recencyname" id="Recencyname_label">Report Label</label>
										</div>
										<input type="text" name="reports[2b3de730-be7e-4a14-b2f3-1e6be27be96f][name][]" class="form-control" id="Recencyname" aria-describedby="Recencyname_label" value="Recency">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="2b3de730-be7e-4a14-b2f3-1e6be27be96ftype">Report Type</label>
										</div>
										<select id="2b3de730-be7e-4a14-b2f3-1e6be27be96ftype" class="custom-select" required name="reports[2b3de730-be7e-4a14-b2f3-1e6be27be96f][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="5e932ae1-deba-4a19-9d78-4033af3d12dbid" id="5e932ae1-deba-4a19-9d78-4033af3d12dbid_label">Report ID</label>
										</div>
										<input type="text" name="reports[5e932ae1-deba-4a19-9d78-4033af3d12db][id][]" required class="form-control" id="5e932ae1-deba-4a19-9d78-4033af3d12dbid" aria-describedby="5e932ae1-deba-4a19-9d78-4033af3d12dbid_label" value="5e932ae1-deba-4a19-9d78-4033af3d12db">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Lab Quality Controlname" id="Lab Quality Controlname_label">Report Label</label>
										</div>
										<input type="text" name="reports[5e932ae1-deba-4a19-9d78-4033af3d12db][name][]" class="form-control" id="Lab Quality Controlname" aria-describedby="Lab Quality Controlname_label" value="Lab Quality Control">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="5e932ae1-deba-4a19-9d78-4033af3d12dbtype">Report Type</label>
										</div>
										<select id="5e932ae1-deba-4a19-9d78-4033af3d12dbtype" class="custom-select" required name="reports[5e932ae1-deba-4a19-9d78-4033af3d12db][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="1b7b7867-bdd8-4e31-938d-0c20565e173aid" id="1b7b7867-bdd8-4e31-938d-0c20565e173aid_label">Report ID</label>
										</div>
										<input type="text" name="reports[1b7b7867-bdd8-4e31-938d-0c20565e173a][id][]" required class="form-control" id="1b7b7867-bdd8-4e31-938d-0c20565e173aid" aria-describedby="1b7b7867-bdd8-4e31-938d-0c20565e173aid_label" value="1b7b7867-bdd8-4e31-938d-0c20565e173a">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Quality Indicatorsname" id="Quality Indicatorsname_label">Report Label</label>
										</div>
										<input type="text" name="reports[1b7b7867-bdd8-4e31-938d-0c20565e173a][name][]" class="form-control" id="Quality Indicatorsname" aria-describedby="Quality Indicatorsname_label" value="Quality Indicators">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="1b7b7867-bdd8-4e31-938d-0c20565e173atype">Report Type</label>
										</div>
										<select id="1b7b7867-bdd8-4e31-938d-0c20565e173atype" class="custom-select" required name="reports[1b7b7867-bdd8-4e31-938d-0c20565e173a][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="447ce3d7-b5fa-4b61-8d76-2cf1175ea353id" id="447ce3d7-b5fa-4b61-8d76-2cf1175ea353id_label">Report ID</label>
										</div>
										<input type="text" name="reports[447ce3d7-b5fa-4b61-8d76-2cf1175ea353][id][]" required class="form-control" id="447ce3d7-b5fa-4b61-8d76-2cf1175ea353id" aria-describedby="447ce3d7-b5fa-4b61-8d76-2cf1175ea353id_label" value="447ce3d7-b5fa-4b61-8d76-2cf1175ea353">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Facility Monitoringname" id="Facility Monitoringname_label">Report Label</label>
										</div>
										<input type="text" name="reports[447ce3d7-b5fa-4b61-8d76-2cf1175ea353][name][]" class="form-control" id="Facility Monitoringname" aria-describedby="Facility Monitoringname_label" value="Facility Monitoring">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="447ce3d7-b5fa-4b61-8d76-2cf1175ea353type">Report Type</label>
										</div>
										<select id="447ce3d7-b5fa-4b61-8d76-2cf1175ea353type" class="custom-select" required name="reports[447ce3d7-b5fa-4b61-8d76-2cf1175ea353][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839id" id="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839id_label">Report ID</label>
										</div>
										<input type="text" name="reports[8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839][id][]" required class="form-control" id="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839id" aria-describedby="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839id_label" value="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="EPI Bulletinname" id="EPI Bulletinname_label">Report Label</label>
										</div>
										<input type="text" name="reports[8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839][name][]" class="form-control" id="EPI Bulletinname" aria-describedby="EPI Bulletinname_label" value="EPI Bulletin">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839type">Report Type</label>
										</div>
										<select id="8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839type" class="custom-select" required name="reports[8e6f2bbd-2681-4b2c-bc0c-e3ba9062c839][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="884d4548-1cec-4390-ba99-47ed4319819eid" id="884d4548-1cec-4390-ba99-47ed4319819eid_label">Report ID</label>
										</div>
										<input type="text" name="reports[884d4548-1cec-4390-ba99-47ed4319819e][id][]" required class="form-control" id="884d4548-1cec-4390-ba99-47ed4319819eid" aria-describedby="884d4548-1cec-4390-ba99-47ed4319819eid_label" value="884d4548-1cec-4390-ba99-47ed4319819e">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Cluster Detection &amp; Responsename" id="Cluster Detection &amp; Responsename_label">Report Label</label>
										</div>
										<input type="text" name="reports[884d4548-1cec-4390-ba99-47ed4319819e][name][]" class="form-control" id="Cluster Detection &amp; Responsename" aria-describedby="Cluster Detection &amp; Responsename_label" value="Cluster Detection &amp; Response">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="884d4548-1cec-4390-ba99-47ed4319819etype">Report Type</label>
										</div>
										<select id="884d4548-1cec-4390-ba99-47ed4319819etype" class="custom-select" required name="reports[884d4548-1cec-4390-ba99-47ed4319819e][type][]">
											<option value="">--</option>
											<option value="power_bi" selected>Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="0d0965112ee147b9859f69d7e64cb250id" id="0d0965112ee147b9859f69d7e64cb250id_label">Report ID</label>
										</div>
										<input type="text" name="reports[0d0965112ee147b9859f69d7e64cb250][id][]" required class="form-control" id="0d0965112ee147b9859f69d7e64cb250id" aria-describedby="0d0965112ee147b9859f69d7e64cb250id_label" value="0d0965112ee147b9859f69d7e64cb250">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="Cluster Detection &amp; Response (Maps)name" id="Cluster Detection &amp; Response (Maps)name_label">Report Label</label>
										</div>
										<input type="text" name="reports[0d0965112ee147b9859f69d7e64cb250][name][]" class="form-control" id="Cluster Detection &amp; Response (Maps)name" aria-describedby="Cluster Detection &amp; Response (Maps)name_label" value="Cluster Detection &amp; Response (Maps)">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="0d0965112ee147b9859f69d7e64cb250type">Report Type</label>
										</div>
										<select id="0d0965112ee147b9859f69d7e64cb250type" class="custom-select" required name="reports[0d0965112ee147b9859f69d7e64cb250][type][]">
											<option value="">--</option>
											<option value="power_bi" >Power BI</option>
											<option value="esri" selected>Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4"  disabled >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove Report" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="id" id="id_label">Report ID</label>
										</div>
										<input type="text" name="reports[][id][]" required class="form-control" id="id" aria-describedby="id_label" value="">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="name" id="name_label">Report Label</label>
										</div>
										<input type="text" name="reports[][name][]" class="form-control" id="name" aria-describedby="name_label" value="">
									</div>
									
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="type">Report Type</label>
										</div>
										<select id="type" class="custom-select" required name="reports[][type][]">
											<option value="">--</option>
											<option value="power_bi" >Power BI</option>
											<option value="esri" >Esri</option>
										</select>								
									</div>
								</div>
								<div class="card-footer d-flex">
									<a href="#" data-toggle="tooltip" title="Move Up" data-action="move" data-direction="up" class="btn btn-info">&uarr;</a>
									<a href="#" data-toggle="tooltip" title="Move Down" data-action="move" data-direction="down" class="btn btn-info ml-auto">&darr;</a>
								</div>
							</fieldset>
														</div>
							<div class="sticky-top py-3 text-right">
								<button type="submit" class="btn btn-lg btn-success">Save</button>
							</div>
							
						</form>
					</div>
				</div>
			</div>

			</div>
			
			<div class="tab-pane fade" id="edit-admin-users">
							<div class="container">
				<div class="row">
					<div class="col-md-12 py-5" id="main_content_users">
						<h2>Auth Proxy Admin
							<br><small class="text-muted">Edit Administrative Users</small>
						</h2>
						
						<div class="text-right py-3">
							<a href="#user_versions_collapse" class="text-muted" data-toggle="collapse">versions</a>
						</div>
						<div class="collapse" id="user_versions_collapse">
							<form class="text-right text-muted py-3" id="version_form_users">
								<div class="input-group">
									<div class="input-group-prepend">
										<label class="input-group-text" for="version_select_users">Versions</label>
									</div>
									
									<select class="custom-select" name="_version_users" id="version_select_users">
										<option value="">LATEST</option>
																			<option value="1594865557"  selected >2020-07-16 02:12:37</option>
																	
									</select>
									<div class="input-group-append">
										<button class="btn btn-outline-secondary" type="submit">ok</button>
									</div>
								</div>
																
							</form>
						</div>
						<form method="post">
							<input type="hidden" name="csrf_test_name" value="ce63651d858a4a25153107b6e26ca3b3" />							<div class="sticky-top py-3 d-flex bg-white border-bottom">
								<button type="button" class="btn btn-lg btn-primary"  data-action="add">Add User</button>
								<button type="submit" class="btn btn-lg btn-success ml-auto">Save</button>
							</div>
							
							<div class="outer">
								
														
							<fieldset class="card mb-4" >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove User" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="0user" id="0user_label">email</label>
										</div>
										<input type="text" name="users[]" required class="form-control" id="0user" aria-describedby="0user_label" value="sbethel@blueraster.com">
									</div>
								</div>
							</fieldset>
														
							<fieldset class="card mb-4"  disabled >
								<div class="card-header">
									<div class="clearfix"><a href="#" data-action="remove" data-toggle="tooltip" title="Remove User" class="close">&times;</a></div>
								</div>
								<div class="card-body">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
											<label class="input-group-text" for="1user" id="1user_label">email</label>
										</div>
										<input type="text" name="users[]" required class="form-control" id="1user" aria-describedby="1user_label" value="">
									</div>
								</div>
							</fieldset>
														</div>
							<div class="sticky-top py-3 text-right">
								<button type="submit" class="btn btn-lg btn-success">Save</button>
							</div>
							
						</form>
					</div>
				</div>
			</div>

			</div>
			
			<div class="tab-pane fade" id="available-updates">
				<style>
	[href="?secure_directory=true"]{
		display: none;
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h3 class="py-3">Update Application</h3>
			<form method="post">
			<input type="hidden" name="csrf_test_name" value="ce63651d858a4a25153107b6e26ca3b3" />			<input type="hidden" name="application_update" value="true">
			<h4 class="text-muted">Review the information below and click 'Continue' to proceed with the installation or update</h4><div class='alert alert-success'><i class='glyphicon glyphicon-ok'></i> Installation directory (/home/dev/domains/pbi-auth.dev.also-too.com/public_html/application/third_party/powerbi_auth_proxy) exists and is writable</div>
<div class='alert alert-success'><i class='glyphicon glyphicon-ok'></i> Zip extension installed</div>
<div class='alert alert-success'><i class='glyphicon glyphicon-ok'></i> cURL extension installed</div><hr style="margin: 40px auto" />
<div class='alert alert-warning'>Application exists but an update is available, so it will be updated</div>
<button type="submit" name="continue" value="true" class="btn btn-primary">Continue?</button>			
			</form>
		</div>
	</div>
</div>


			</div>
			
		</div>
					
		
		
		<script src="//code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha256-4+XzXVhsDmqanXGHaHvgh1gMQKX40OUvDEBTu8JcmNs=" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>		
		<script>
			
			
			(function(){
				var _this = this;
				
				_this.opener = window.opener;
				
				_this.page_data = JSON.parse($('[type="text/template"]').html());


				_this.move = function(e, data){
					var report = $(this).parents('fieldset');
					if(data.direction === 'up'){
						report.prev().before(report);
					}
					else{
						report.next().after(report);
					}
				}
				
				
				_this.remove = function(e, data){
					if(confirm('Are you sure you would like to remove this item?')){
						$(this).parents('fieldset').remove();
					}
				}
				
				
				
				_this.add = function(e, data){
					var tp = $(this).parents('.tab-pane');
					var id = tp[0].id;
					var tpl = $(_this.templates[id]).clone();
					var mockid = Date.now() + '';
					tpl.find('[name]').each(function(){
						this.name = this.name.replace(/reports\[\]/, 'reports['+mockid+']');
					});
					$(tpl).prependTo(tp.find('.outer')).find('input').first().focus();

				}
				
				function handle(e){
					e.preventDefault();
					var data = $(this).data();
					_this[data.action].call(this, e, data);
				}
				
				$(document).on('click', '[data-action]', handle);
				
				$(document).on('change', '[name*="_version"]', function(){
					console.log(this.form);
					this.form.submit();
					// var href = _this.opener.location.href;
					// var newhref = href.replace(_this.opener.location.search, '?_version=' + this.value);
					// _this.opener.location.assign(newhref);
					// console.log(newhref);
				});
				
								
				
				(function(){
					_this.templates = $('.tab-pane').toArray().reduce(function(current, node){
						var _tpl = $(node).find('.outer fieldset[disabled]');
						if(!_tpl.length) return current;
						var tpl = _tpl.clone();
						_tpl.remove();
						
						tpl.find('[name], label').each(function (){
							this.removeAttribute('id');
							this.removeAttribute('for');
							this.removeAttribute('aria-describedby');
						});
						var template = tpl[0];
						template.removeAttribute('disabled');
						current[node.id] = template;
						return current;
						
					}, {});

					// user messages
					if(localStorage._auth_proxy_message){
						$('<div class="alert alert-success">'+localStorage._auth_proxy_message+'<a class="close auth-proxy-reload-main-page" href="#" data-toggle="tooltip" title="Close message and reload main window to view changes" data-dismiss="alert">&times;</a></div>').prependTo('#messages');
						delete localStorage._auth_proxy_message;
						
					}
					if(localStorage._auth_proxy_error){
						$('<div class="alert alert-danger">'+localStorage._auth_proxy_error+'<a class="close " href="#" data-toggle="tooltip" title="Close message" data-dismiss="alert">&times;</a></div>').prependTo('#messages');
						delete localStorage._auth_proxy_message;
						
					}
					$(document).on('click', '.auth-proxy-reload-main-page', function(){
						if(window.opener){
							window.opener.location.reload();
						}
					});
					
					$('[data-toggle="tooltip"]').tooltip();
					
					$(window).on('hashchange load', function(){
						if(window.location.hash){
							$('[href="'+window.location.hash+'"]').tab('show');
						}
					});
				})();
				
			})()
			
		</script>
	</body>
</html>
	
